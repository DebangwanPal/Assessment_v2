package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import base.testBase;

public class Capture extends testBase{
 
	public static void takeScreenShots() throws IOException 
	{
		TakesScreenshot takeScreenshot = (TakesScreenshot) driver;
		File source = takeScreenshot.getScreenshotAs(OutputType.FILE);
 
		File dest = new File(System.getProperty("user.dir") + "/src/main/resources/Screenshots/"+DateUtils.getTimeStamp()+".png");
				
		FileUtils.copyFile(source, dest);
 
	}
}
