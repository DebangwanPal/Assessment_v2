package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.testBase;
import tripAdvisorPage.tripAdvisor;
import utils.Capture;
import dataProvider.ExcelDataProvider;

import java.util.List;


public class tripAdvisorTest extends testBase
{
	tripAdvisor obj;
	
	@BeforeClass
	public void setPage() {
		obj = new tripAdvisor(driver);
		
	}
	@Test(priority = 1, enabled = true)
	public void HotelsClick() throws InterruptedException {
		driver.findElement(By.xpath("//*[@href=\'/Hotels\']")).click();
		Thread.sleep(1000);
		driver.get("www.tripadvisor.com/Hotels");
	}
	@Test(priority=2, enabled=true)
	public void search() {
		String data = ExcelDataProvider.readExcel(0);
		driver.findElement(By.xpath("//*[@placeholder=\'Hotel name or destination\']")).sendKeys(data);
		driver.findElement(By.xpath("//*[@placeholder=\'Hotel name or destination\']")).sendKeys(Keys.TAB);

	}
	@Test(priority = 3, enabled = false)
	public void searchButton() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//*[@class=\'biGQs _P fiohW avBIb EIWOD S5\'])[1]")).click();
	}
	
	@Test(priority=3, enabled=true)
	public void checkin() throws InterruptedException 
	{
		driver.findElement((By.xpath("//*[@data-datetype='CHECKIN']"))).click();
		Thread.sleep(2000);

		String data = ExcelDataProvider.readExcel(1);
		String checkinDate = data.substring(3, 11);
	//	System.out.println("checkin "+checkinDate);
		String dateval = data.substring(0, 2);

		while(true)
		{
			String txt=driver.findElement(By.xpath("//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")).getText();
			//System.out.println(txt);
			if(txt.equalsIgnoreCase(checkinDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				driver.findElement(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")).click();

		}
	/*	String txt = null;
		while (!(checkinDate.equalsIgnoreCase(txt))){
			txt=driver.findElement(By.xpath("//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")).getText();
			driver.findElement(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")).click();
		}	*/

		List<WebElement> datelist = driver.findElements(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span"));
		for(WebElement element:datelist)
		{
			String date = element.getText();
			if(date.equals(dateval)) {
				Thread.sleep(1000);
				element.click();
				break;
			}
		}
	}
	
	@Test(priority=4, enabled=true)
	public void checkout() throws InterruptedException 
	{
		driver.findElement((By.xpath("//*[@data-datetype='CHECKOUT']"))).click();
		Thread.sleep(2000);

		String data = ExcelDataProvider.readExcel(2);
		String checkoutDate = data.substring(3, 11);

		String dateval = data.substring(0, 2);

		while(true)
		{
			String txt=driver.findElement(By.xpath("//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")).getText();

			if(txt.equalsIgnoreCase(checkoutDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				driver.findElement(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")).click();

		}

		List<WebElement> datelist = driver.findElements(By.xpath("//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span"));
		for(WebElement element:datelist)
		{
			String date = element.getText();
			if(date.equals(dateval))
			{
				Thread.sleep(1000);
				element.click();
				break;
			}
		}
	}
	
	@Test(priority=4, enabled=true)
	public void rooms()
	{
		WebElement number = driver.findElement((By.xpath("//*[@class=\'ui_icon caret-down\']")));
		number.click();
		String data = new String();
		data = ExcelDataProvider.readExcel(3);
		int data1 = Integer.parseInt(data);
		WebElement room = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[1]/div/span[2]")));
		String rum = room.getText();
		char c = rum.charAt(0);
		int Room = Character.getNumericValue(c);
		while(data1!=Room)
		{
			if(data1 > Room)
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Room)
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle"))).click();
			}
			rum = room.getText();
			c = rum.charAt(0);
			Room = Character.getNumericValue(c);
		}
	}
	
	@Test(dependsOnMethods= {"rooms"}, priority=5, enabled=true)
	public void noofadults() 
	{
		WebElement adult = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[2]/div/span[2]")));
		String adlt = adult.getText();
		char c = adlt.charAt(0);
		int Adult = Character.getNumericValue(c);
		String data = ExcelDataProvider.readExcel(4);
		int data1 = Integer.parseInt(data);
		while(data1!=Adult)
		{
			if(data1 > Adult)
			{
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Adult) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle"))).click();
			}
			adlt = adult.getText();
			c = adlt.charAt(0);
			Adult = Character.getNumericValue(c);
		}
	}
	
	@Test(dependsOnMethods= {"rooms"}, priority=6, enabled=true)
	public void noofchildren() 
	{
		WebElement child = driver.findElement((By.xpath("//*[@id=\'BODY_BLOCK_JQUERY_REFLOW\']/span/div[3]/div/div[3]/div/span[2]")));
		String chld = child.getText();
		char c = chld.charAt(0);
		int Child = Character.getNumericValue(c);
		String data = ExcelDataProvider.readExcel(5);
		int data1 = Integer.parseInt(data);
		while(data1!=Child) {
			if(data1 > Child) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle"))).click();
			}
			else if(data1 < Child) {
				driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle.inactive"))).click();
			}
			chld = child.getText();
			c = chld.charAt(0);
			Child = Character.getNumericValue(c);
		}

		driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > span.picker-inner"))).click();
		driver.findElement((By.cssSelector("#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > div > span > ul.options-container > li:nth-child(8)"))).click();
	}
	
	
}








