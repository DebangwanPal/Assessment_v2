package tripAdvisorPage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import dataProvider.ExcelDataProvider;

public class tripAdvisor 
{
	public tripAdvisor(WebDriver driver) 
	{
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//input[@placeholder='Hotel name or destination']")
	WebElement searchBox;
	public void searchBox() {
		String data = new String();
		data = ExcelDataProvider.readExcel(0);
		searchBox.sendKeys("Sonar Bangla Resort");
	//	searchBox.sendKeys(data);
	//	searchBox.sendKeys(Keys.TAB);
	}
	
	@FindBy(xpath="//*[@data-datetype='CHECKIN']")
	WebElement checkinclick;
	@FindBy(xpath="//*[@id=\\\"BODY_BLOCK_JQUERY_REFLOW\\\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")
	WebElement monthandyear;
	@FindBy(xpath="//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")
	WebElement next;
	@FindBy(xpath="//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span")
	List<WebElement> datelist;
	public void checkIn() throws InterruptedException 
	{ 
		checkinclick.click();
		Thread.sleep(2000);
		 
		String data = ExcelDataProvider.readExcel(1);
		String checkinDate = data.substring(3, 11);
		String dateval = data.substring(0, 2); 
		
		while(true) 
		{
			String txt=monthandyear.getText();
			
			if(txt.equalsIgnoreCase(checkinDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				next.click();
		}
		
		for(WebElement element:datelist) 
		{
			String date = element.getText();
			if(date.equals(dateval)) {
				Thread.sleep(1000);
				element.click();
				break;
			}
		}
	}
	
	@FindBy(xpath="//*[@data-datetype='CHECKIN']")
	WebElement checkoutclick;
	@FindBy(xpath="//*[@id=\\\"BODY_BLOCK_JQUERY_REFLOW\\\"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]")
	WebElement monthandyearchechout;
	@FindBy(xpath="//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[1]")
	WebElement nextcheckout;
	@FindBy(xpath="//*[@id='BODY_BLOCK_JQUERY_REFLOW']/span/div[3]/div/div[2]/div[3]/span[1]/span")
	List<WebElement> datelistcheckout;
	public void checkOut() throws InterruptedException 
	{ 
		checkoutclick.click();
		Thread.sleep(2000);
		 
		String data = ExcelDataProvider.readExcel(1);
		String checkinDate = data.substring(3, 11);
		String dateval = data.substring(0, 2); 
		
		while(true) 
		{
			String txt=monthandyearchechout.getText();
			
			if(txt.equalsIgnoreCase(checkinDate))
				break;//*[@id="BODY_BLOCK_JQUERY_REFLOW"]/span/div[3]/div/div[2]/div[3]/span[1]/span[1]
			else
				nextcheckout.click();
		}
		
		for(WebElement element:datelistcheckout) 
		{
			String date = element.getText();
			if(date.equals(dateval)) {
				Thread.sleep(1000);
				element.click();
				break;
			}
		}
	}
	
	@FindBy(xpath="//*[@class=\\'ui_icon caret-down\\']")
	WebElement number;
	@FindBy(xpath="//*[@id=\\'BODY_BLOCK_JQUERY_REFLOW\\']/span/div[3]/div/div[1]/div/span[2]")
	WebElement room;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle")
	WebElement case1;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.roomsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle")
	WebElement case2;
	public void rooms() 
	{
		number.click();
		String data = new String();
		data = ExcelDataProvider.readExcel(3);
		int data1 = Integer.parseInt(data);
		
		String rum = room.getText();
		char c = rum.charAt(0);
		int Room = Character.getNumericValue(c);
		while(data1!=Room) 
		{
			if(data1 > Room) 
			{
				case1.click();
			}
			else if(data1 < Room)
			{
				case2.click();
			}
			rum = room.getText();
			c = rum.charAt(0);
			Room = Character.getNumericValue(c);
		}
	}
	
	@FindBy(xpath="//*[@id=\\'BODY_BLOCK_JQUERY_REFLOW\\']/span/div[3]/div/div[2]/div/span[2]")
	WebElement adult;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle")
	WebElement situation1;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.adultsPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle")
	WebElement situation2;
	public void adults() 
	{
		String adlt = adult.getText();
		char c = adlt.charAt(0);
		int Adult = Character.getNumericValue(c);
		String data = ExcelDataProvider.readExcel(4);
		int data1 = Integer.parseInt(data);
		while(data1!=Adult) 
		{
			if(data1 > Adult) 
			{
				situation1.click();
			}
			else if(data1 < Adult) {
				situation2.click();
			}
			adlt = adult.getText();
			c = adlt.charAt(0);
			Adult = Character.getNumericValue(c);
		}
	}
	@FindBy(xpath="//*[@id=\\'BODY_BLOCK_JQUERY_REFLOW\\']/span/div[3]/div/div[3]/div/span[2]")
	WebElement child;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.plus-circle")
	WebElement c1;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.childrenPlaceholder > div > span.ui_selector > span.ui_icon.minus-circle.inactive")
	WebElement c2;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > span.picker-inner")
	WebElement clk1;
	@FindBy(css="#BODY_BLOCK_JQUERY_REFLOW > span > div.body_text > div > div.ages-wrap > span > span > div > span > ul.options-container > li:nth-child(8)")
	WebElement clk2;
	public void children() 
	{
		String chld = child.getText();
		char c = chld.charAt(0);
		int Child = Character.getNumericValue(c);
		String data = ExcelDataProvider.readExcel(5);
		int data1 = Integer.parseInt(data);
		while(data1!=Child) {
			if(data1 > Child) {
				c1.click();
			}
			else if(data1 < Child) {
				c2.click();
			}
			chld = child.getText();
			c = chld.charAt(0);
			Child = Character.getNumericValue(c);
		}	

		clk1.click();
		clk2.click();
	}
}







